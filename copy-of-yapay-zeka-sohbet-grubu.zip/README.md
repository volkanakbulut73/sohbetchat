<div align="center">
  <h1 align="center">Workigom Chat</h1>
  <p align="center">Güvenli, Modern ve Nostaljik Sohbet Platformu</p>
</div>

## Proje Hakkında

Bu proje, **mIRC** kültürünü modern web teknolojileriyle birleştiren, yapay zeka destekli ve güvenli bir sohbet uygulamasıdır. Kullanıcıların kimlik doğrulaması ile katıldığı, botlarla etkileşime geçebildiği hibrit bir yapı sunar.

🔗 **Repository:** [https://github.com/volkanakbulut73/sohbet](https://github.com/volkanakbulut73/sohbet)

## Kurulum ve Çalıştırma

1. Bağımlılıkları yükleyin:
   ```bash
   npm install
   ```

2. Geliştirme sunucusunu başlatın:
   ```bash
   npm run dev
   ```

## GitHub'a Gönderme (Deploy)

Bu projeyi `https://github.com/volkanakbulut73/sohbet` deposuna göndermek için terminalinizde şu komutları sırasıyla çalıştırın:

1. **Git'i Başlatın (Eğer başlatılmadıysa):**
   ```bash
   git init
   ```

2. **Tüm Dosyaları Ekleyin:**
   ```bash
   git add .
   ```

3. **Versiyon Commit'i Oluşturun:**
   ```bash
   git commit -m "Proje kurulumu ve Landing Page entegrasyonu tamamlandı"
   ```

4. **Ana Branch İsmimi Belirleyin:**
   ```bash
   git branch -M main
   ```

5. **Uzak Depoyu Ekleyin:**
   ```bash
   git remote add origin https://github.com/volkanakbulut73/sohbet.git
   ```
   *(Not: Eğer "remote origin already exists" hatası alırsanız: `git remote set-url origin https://github.com/volkanakbulut73/sohbet.git` komutunu kullanın)*

6. **GitHub'a Gönderin (Push):**
   ```bash
   git push -u origin main
   ```

## Yayına Alma (Vercel)

Bu proje Vercel ile tam uyumludur. GitHub'a push işlemi yaptıktan sonra:
1. **Vercel** panelinize gidin.
2. "Add New Project" diyerek GitHub hesabınızdaki `sohbet` deposunu seçin.
3. Ayarları değiştirmeden **Deploy** butonuna basın.

---
Workigom Network System © 2024
