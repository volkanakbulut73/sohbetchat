import { storageService } from "./storageService";
import { Participant, Message } from '../types';

// API Configuration
const API_KEY = "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";
const MODEL = "llama-3.1-8b-instant";

/**
 * Shared function to call Groq API
 */
async function callGroqApi(messages: any[], temperature: number = 0.7): Promise<string> {
    try {
        const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
            method: "POST",
            headers: {
                "Authorization": `Bearer ${API_KEY}`,
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                model: MODEL,
                messages: messages,
                temperature: temperature,
                max_tokens: 300
            })
        });

        if (!response.ok) {
            console.error("Groq API Error:", response.statusText);
            return "... (Bağlantı hatası)";
        }

        const data = await response.json();
        return data?.choices?.[0]?.message?.content || "...";
    } catch (error) {
        console.error("Groq Network Error:", error);
        return "... (Hata)";
    }
}

/**
 * Function used by the main App.tsx (Modern UI)
 */
export const generateBotResponse = async (
    targetBot: Participant,
    allParticipants: Participant[],
    chatHistory: Message[],
    topic: string
): Promise<string> => {
    
    // 1. Prepare Context
    const participantDescriptions = allParticipants
        .map(p => `- ${p.name} (${p.isAi ? 'Yapay Zeka' : 'İnsan'}): ${p.persona}`)
        .join('\n');

    const recentMessages = chatHistory.slice(-10); // Last 10 messages
    const conversationLog = recentMessages.map(msg => {
        const sender = allParticipants.find(p => p.id === msg.senderId);
        const senderName = sender ? sender.name : 'Bilinmeyen';
        return `${senderName}: ${msg.text}`;
    }).join('\n');

    // 2. Construct Prompt
    const systemPrompt = `
Bu bir grup sohbeti simülasyonudur.
Konu: ${topic}

Katılımcılar:
${participantDescriptions}

Senin Rolün:
Adın: ${targetBot.name}
Kişiliğin: ${targetBot.persona}

Kurallar:
1. Sadece ${targetBot.name} olarak cevap ver.
2. Adını mesajın başına yazma.
3. Rolüne sadık kal, kısa ve doğal konuş.
4. Diğer katılımcıların mesajlarına atıfta bulunabilirsin.
`;

    // 3. Create Messages Array
    const messages = [
        { role: "system", content: systemPrompt },
        { role: "user", content: `Sohbet Geçmişi:\n${conversationLog}\n\n(Sıra sende, cevap ver)` }
    ];

    return await callGroqApi(messages, 0.8);
};

/**
 * Legacy Service Object (used by useChatCore.ts / mIRC mode)
 */
export const groqService = {
  async getChatResponse(prompt: string, sender: string, retries = 1): Promise<string> {
    try {
      // Dinamik bot eğitimi/kişiliği veritabanından çekiliyor
      const botPersonality = await storageService.getBotConfig();

      const messages = [
            { 
              role: "system", 
              content: `${botPersonality}
              - Sohbet ettiğin kişinin nicki: ${sender}.
              - Cevapların kısa, öz ve Türkçe olsun.
              - mIRC jargonunu asla bırakma.` 
            },
            { role: "user", content: prompt }
      ];

      const response = await callGroqApi(messages, 0.8);
      
      if (response === "... (Bağlantı hatası)" && retries > 0) {
          await new Promise(resolve => setTimeout(resolve, 2000));
          return this.getChatResponse(prompt, sender, retries - 1);
      }
      
      return response;

    } catch (error) {
      return "Sistem: Bağlantı hatası oluştu (Ping timeout).";
    }
  }
};