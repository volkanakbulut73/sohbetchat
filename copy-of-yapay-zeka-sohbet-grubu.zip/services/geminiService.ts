// This service is deprecated. The application now uses groqService.ts
export const generateBotResponse = async () => {
    console.warn("Gemini service is disabled.");
    return "Service Disabled";
};