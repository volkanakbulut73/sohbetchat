import React from 'react';

// Bu bileşen artık kullanılmamaktadır.
// Navigasyon App.tsx içerisindeki Tab yapısı ile sağlanmaktadır.

export const Sidebar: React.FC<any> = () => {
  return null;
};