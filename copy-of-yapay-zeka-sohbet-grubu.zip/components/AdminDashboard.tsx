
import React, { useState, useEffect } from 'react';
import { 
  Users, 
  CheckCircle, 
  XCircle, 
  ShieldCheck, 
  Clock, 
  FileText, 
  LogOut,
  RefreshCw,
  Search,
  Loader2,
  Megaphone,
  Mail,
  Send,
  MessageSquare,
  History,
  AlertTriangle,
  WifiOff,
  Bot
} from 'lucide-react';
import { storageService } from '../services/storageService';
import { UserRegistration, Channel } from '../types';

interface AdminDashboardProps {
  onLogout: () => void;
}

type AdminTab = 'registrations' | 'notifications' | 'bot';

const AdminDashboard: React.FC<AdminDashboardProps> = ({ onLogout }) => {
  const [registrations, setRegistrations] = useState<UserRegistration[]>([]);
  const [channels, setChannels] = useState<Channel[]>([]);
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<AdminTab>('registrations');
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [selectedDoc, setSelectedDoc] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  // Bot Training States
  const [botPersonality, setBotPersonality] = useState('');
  const [botSaving, setBotSaving] = useState(false);

  // Notification states
  const [chatNotif, setChatNotif] = useState({ channel: 'all', message: '' });
  const [emailNotif, setEmailNotif] = useState({ target: 'all', subject: '', message: '' });
  const [notifSending, setNotifSending] = useState(false);

  const loadData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [regs, chns, history, botCfg] = await Promise.all([
        storageService.getAllRegistrations(),
        storageService.getChannels(),
        storageService.getNotificationLogs(),
        storageService.getBotConfig()
      ]);
      setRegistrations(regs);
      setChannels(chns);
      setLogs(history);
      setBotPersonality(botCfg);
    } catch (err: any) {
      setError(err.message || "Veriler yüklenirken bir hata oluştu.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleBotUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setBotSaving(true);
    try {
      await storageService.updateBotConfig(botPersonality);
      alert("Lara başarıyla eğitildi! Artık yeni talimatlarına göre davranacak.");
    } catch (err: any) {
      alert("Hata: " + err.message);
    } finally {
      setBotSaving(false);
    }
  };

  const handleStatusUpdate = async (id: string, status: 'approved' | 'rejected') => {
    setProcessingId(id);
    try {
      await storageService.updateRegistrationStatus(id, status);
      await loadData();
    } catch (err: any) { alert(err.message); }
    finally { setProcessingId(null); }
  };

  const handleChatNotify = async (e: React.FormEvent) => {
    e.preventDefault();
    setNotifSending(true);
    try {
      await storageService.sendChatNotification(chatNotif.channel, chatNotif.message);
      setChatNotif({ ...chatNotif, message: '' });
      await loadData();
    } catch (err: any) { alert(err.message); }
    finally { setNotifSending(false); }
  };

  const filtered = registrations.filter(r => {
    const matchesFilter = filter === 'all' || r.status === filter;
    const matchesSearch = r.nickname.toLowerCase().includes(searchTerm.toLowerCase()) || r.email.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-[#0b0f14] text-gray-300 font-mono flex flex-col">
      <header className="h-16 bg-gray-900 border-b border-gray-800 flex items-center justify-between px-6 shrink-0">
        <div className="flex items-center gap-3">
          <div className="bg-[#00ff99] p-2 rounded-sm text-black"><ShieldCheck size={20} /></div>
          <div>
            <h1 className="text-white font-black text-sm uppercase">Workigom Control Center</h1>
            <p className="text-[9px] text-gray-500 font-bold uppercase tracking-widest">Global Administration</p>
          </div>
        </div>
        <button onClick={onLogout} className="text-xs font-bold text-red-500 hover:text-white uppercase flex items-center gap-2"><LogOut size={16} /> Çıkış</button>
      </header>

      <div className="flex-1 flex overflow-hidden">
        <aside className="w-64 bg-gray-900/50 border-r border-gray-800 p-4 space-y-6 hidden md:block">
          <div className="space-y-1">
            <button onClick={() => setActiveTab('registrations')} className={`w-full flex items-center gap-3 px-4 py-3 text-xs font-bold rounded-sm ${activeTab === 'registrations' ? 'bg-[#00ff99] text-black shadow-lg' : 'hover:bg-gray-800'}`}><Users size={16} /> Kullanıcılar</button>
            <button onClick={() => setActiveTab('notifications')} className={`w-full flex items-center gap-3 px-4 py-3 text-xs font-bold rounded-sm ${activeTab === 'notifications' ? 'bg-[#00ff99] text-black shadow-lg' : 'hover:bg-gray-800'}`}><Megaphone size={16} /> Bildirimler</button>
            <button onClick={() => setActiveTab('bot')} className={`w-full flex items-center gap-3 px-4 py-3 text-xs font-bold rounded-sm ${activeTab === 'bot' ? 'bg-[#00ff99] text-black shadow-lg' : 'hover:bg-gray-800'}`}><Bot size={16} /> Bot Eğitimi (Lara)</button>
          </div>
        </aside>

        <main className="flex-1 flex flex-col p-6 overflow-hidden">
          {error ? (
            <div className="flex-1 flex flex-col items-center justify-center space-y-4">
              <AlertTriangle size={48} className="text-red-500" />
              <p className="text-xs uppercase font-black">{error}</p>
              <button onClick={loadData} className="bg-[#00ff99] text-black px-6 py-2 text-xs font-black uppercase">Tekrar Dene</button>
            </div>
          ) : activeTab === 'registrations' ? (
            <>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-black text-white uppercase italic">Kullanıcı Yönetimi</h2>
                <div className="flex gap-2">
                  <select value={filter} onChange={e => setFilter(e.target.value as any)} className="bg-gray-800 text-[10px] p-2 outline-none border border-gray-700">
                    <option value="all">Tümü</option>
                    <option value="pending">Onay Bekleyen</option>
                    <option value="approved">Onaylı</option>
                    <option value="rejected">Reddedilen</option>
                  </select>
                  <input type="text" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} placeholder="Ara..." className="bg-gray-900 border border-gray-700 text-xs py-2 px-4 outline-none focus:border-[#00ff99]" />
                </div>
              </div>
              <div className="flex-1 overflow-y-auto bg-gray-900/30 border border-gray-800">
                <table className="w-full text-left text-[11px]">
                  <thead className="bg-gray-900 text-gray-500 uppercase font-black">
                    <tr>
                      <th className="p-4 border-b border-gray-800">Üye</th>
                      <th className="p-4 border-b border-gray-800">Nick</th>
                      <th className="p-4 border-b border-gray-800">Durum</th>
                      <th className="p-4 border-b border-gray-800">Belgeler</th>
                      <th className="p-4 border-b border-gray-800 text-right">İşlem</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-800">
                    {filtered.map(reg => (
                      <tr key={reg.id} className="hover:bg-white/5">
                        <td className="p-4"><div className="flex flex-col"><span className="font-bold text-white">{reg.fullName}</span><span className="text-[10px] text-gray-500">{reg.email}</span></div></td>
                        <td className="p-4 text-[#00ff99]">@{reg.nickname}</td>
                        <td className="p-4 uppercase font-black">{reg.status}</td>
                        <td className="p-4"><div className="flex gap-1"><button onClick={() => setSelectedDoc(reg.criminal_record_file!)} className="p-1 bg-gray-800 rounded"><FileText size={14}/></button><button onClick={() => setSelectedDoc(reg.insurance_file!)} className="p-1 bg-gray-800 rounded"><FileText size={14}/></button></div></td>
                        <td className="p-4 text-right">
                          <div className="flex justify-end gap-1">
                            {reg.status !== 'approved' && <button onClick={() => handleStatusUpdate(reg.id!, 'approved')} className="p-1 bg-green-600 text-white rounded"><CheckCircle size={14}/></button>}
                            {reg.status !== 'rejected' && <button onClick={() => handleStatusUpdate(reg.id!, 'rejected')} className="p-1 bg-red-600 text-white rounded"><XCircle size={14}/></button>}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          ) : activeTab === 'bot' ? (
            <div className="flex-1 flex flex-col space-y-6">
              <div className="flex flex-col">
                <h2 className="text-2xl font-black text-white italic uppercase flex items-center gap-3">
                  <Bot className="text-[#00ff99]" size={28} /> LARA BOT EĞİTİMİ
                </h2>
                <p className="text-[10px] text-gray-500 mt-1 uppercase font-bold border-l-2 border-[#00ff99] pl-3">Botun kişiliğini, kurallarını ve bilgisini buradan güncelleyin.</p>
              </div>

              <form onSubmit={handleBotUpdate} className="flex-1 flex flex-col space-y-4">
                <div className="flex-1 flex flex-col space-y-2">
                  <label className="text-[10px] font-black text-[#00ff99] uppercase">Lara'nın Kişilik Dosyası & Talimatları:</label>
                  <textarea 
                    value={botPersonality}
                    onChange={e => setBotPersonality(e.target.value)}
                    className="flex-1 bg-black border-2 border-gray-800 p-6 text-white text-xs outline-none focus:border-[#00ff99] font-mono leading-relaxed shadow-inner"
                    placeholder="Lara nasıl davranmalı? Örn: Sen nazik bir mIRC botusun. Küfür edenleri uyar. Fenerbahçelisin..."
                  />
                  <div className="bg-blue-900/20 border border-blue-500/30 p-3 text-[10px] text-blue-300 italic">
                    [ İpucu ]: Ne kadar detaylı yazarsanız Lara o kadar gerçekçi davranır. Ona yasaklı konuları, sevdiği şeyleri ve cevap verme stilini belirtin.
                  </div>
                </div>
                <button 
                  type="submit" 
                  disabled={botSaving}
                  className="bg-[#00ff99] text-black py-4 font-black uppercase text-xs flex items-center justify-center gap-2 hover:bg-white transition-all shadow-[6px_6px_0px_rgba(255,255,255,0.1)] active:translate-y-1"
                >
                  {botSaving ? <Loader2 className="animate-spin" size={16} /> : <RefreshCw size={16} />}
                  LARA'YI EĞİT VE KAYDET
                </button>
              </form>
            </div>
          ) : (
            <div className="space-y-8">
              <h2 className="text-xl font-black text-white uppercase italic flex items-center gap-2"><Megaphone className="text-[#00ff99]" /> Bildirim Merkezi</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-gray-900/50 p-6 border border-gray-800 space-y-4">
                  <h3 className="text-xs font-black uppercase border-b border-gray-800 pb-2">Sohbet Odası Anonsu</h3>
                  <form onSubmit={handleChatNotify} className="space-y-3">
                    <select value={chatNotif.channel} onChange={e => setChatNotif({...chatNotif, channel: e.target.value})} className="w-full bg-black border border-gray-700 p-2 text-xs text-white">
                      <option value="all">Tüm Kanallar</option>
                      {channels.map(c => <option key={c.name} value={c.name}>{c.name}</option>)}
                    </select>
                    <textarea value={chatNotif.message} onChange={e => setChatNotif({...chatNotif, message: e.target.value})} className="w-full bg-black border border-gray-700 p-2 text-xs text-white h-24 resize-none" placeholder="Anons metni..."></textarea>
                    <button type="submit" disabled={notifSending} className="w-full bg-[#00ff99] text-black py-2 text-[10px] font-black uppercase">Yayınla</button>
                  </form>
                </div>
                <div className="bg-black/40 p-4 border border-gray-800 max-h-64 overflow-y-auto">
                  <h3 className="text-[10px] font-black text-gray-500 uppercase mb-2">Log Kayıtları</h3>
                  <div className="space-y-1 font-mono text-[9px]">
                    {logs.map(log => <div key={log.id} className="text-gray-400 border-b border-gray-800 py-1">[{new Date(log.created_at).toLocaleTimeString()}] {log.type.toUpperCase()} -> {log.target}</div>)}
                  </div>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {selectedDoc && (
        <div className="fixed inset-0 bg-black/95 z-[500] flex items-center justify-center p-10" onClick={() => setSelectedDoc(null)}>
          <img src={selectedDoc} alt="Belge" className="max-h-full object-contain" />
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
