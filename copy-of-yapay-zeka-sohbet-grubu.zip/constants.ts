import { Participant, ChatRoom } from './types';

export const AVATAR_COLORS = [
  'bg-red-500', 'bg-orange-500', 'bg-amber-500', 'bg-yellow-500', 
  'bg-lime-500', 'bg-green-500', 'bg-emerald-500', 'bg-teal-500', 
  'bg-cyan-500', 'bg-sky-500', 'bg-blue-500', 'bg-indigo-500', 
  'bg-violet-500', 'bg-purple-500', 'bg-fuchsia-500', 'bg-pink-500', 'bg-rose-500'
];

export const INITIAL_USER: Participant = {
  id: 'user-1',
  name: 'Sen',
  persona: 'User',
  avatar: 'https://picsum.photos/id/64/200/200',
  isAi: false,
  color: 'bg-slate-700'
};

export const PREMADE_BOTS: Participant[] = [
  {
    id: 'bot-socrates',
    name: 'Sokrates',
    persona: 'Sen antik Yunan filozofu Sokrates\'sin. Her şeye soruyla karşılık verirsin, bilgelik ararsın ve insanları düşündürmeye çalışırsın. Kısa ve özlü konuş.',
    avatar: 'https://picsum.photos/id/1025/200/200',
    isAi: true,
    color: 'bg-stone-600'
  },
  {
    id: 'bot-einstein',
    name: 'Einstein',
    persona: 'Sen Albert Einstein\'sın. Meraklı, zeki ve biraz da esprili bir fizikçisin. Karmaşık konuları basit metaforlarla açıklarsın. Almanca kelimeler kullanabilirsin arada.',
    avatar: 'https://picsum.photos/id/1012/200/200',
    isAi: true,
    color: 'bg-blue-600'
  },
  {
    id: 'bot-chef',
    name: 'Şef Gusto',
    persona: 'Sen tutkulu ve biraz agresif bir İtalyan şefsin. Yemek metaforlarını çok seversin. Her konuda lezzet ve tutku ararsın. "Mamma mia!" gibi tepkiler verirsin.',
    avatar: 'https://picsum.photos/id/292/200/200',
    isAi: true,
    color: 'bg-red-600'
  },
  {
    id: 'bot-alien',
    name: 'Zorg',
    persona: 'Sen dünyayı keşfetmeye gelmiş dost canlısı ama şaşkın bir uzaylısın. İnsan davranışlarını anlamakta zorlanırsın ve bunları tuhaf bulursun.',
    avatar: 'https://picsum.photos/id/1024/200/200',
    isAi: true,
    color: 'bg-green-600'
  }
];

export const INITIAL_ROOM: ChatRoom = {
  id: 'room-1',
  name: 'Felsefe Kulübü',
  topic: 'Hayatın anlamı ve evrenin sırları',
  participants: [INITIAL_USER, PREMADE_BOTS[0], PREMADE_BOTS[1]],
  messages: [
    {
      id: 'msg-1',
      senderId: 'bot-socrates',
      text: 'Hoş geldiniz dostlarım. Bugün bildiğimiz tek şeyin, hiçbir şey bilmediğimiz olduğu üzerine mi konuşacağız?',
      timestamp: Date.now() - 100000
    }
  ],
  lastMessageAt: Date.now(),
  type: 'channel',
  hasAlert: false
};