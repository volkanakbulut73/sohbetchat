import React, { useState, useCallback, useEffect } from 'react';
import { ChatArea } from './components/ChatArea';
import { RightPanel } from './components/RightPanel';
import LandingPage from './components/LandingPage';
import RegistrationForm from './components/RegistrationForm';
import AdminDashboard from './components/AdminDashboard';
import { ChatRoom, Message, Participant, LoadingState } from './types';
import { INITIAL_ROOM, INITIAL_USER, PREMADE_BOTS } from './constants';
import { generateBotResponse } from './services/groqService';
import { Plus, X, Shield, Settings, Power, Minus, Square, Save } from 'lucide-react';

const App: React.FC = () => {
  // Navigation State
  const [currentView, setCurrentView] = useState<'LANDING' | 'CHAT' | 'REGISTER' | 'ADMIN'>('LANDING');

  // Initial Room Setup needs type: 'channel'
  const initialRoomWithProps: ChatRoom = { ...INITIAL_ROOM, type: 'channel', hasAlert: false };
  
  const [currentUser, setCurrentUser] = useState<Participant>(INITIAL_USER);
  const [rooms, setRooms] = useState<ChatRoom[]>([initialRoomWithProps]);
  const [activeRoomId, setActiveRoomId] = useState<string>(initialRoomWithProps.id);
  const [loadingState, setLoadingState] = useState<LoadingState>({ status: 'idle' });
  
  // Settings & State
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [newRoomName, setNewRoomName] = useState('');
  
  // User Settings
  const [tempNick, setTempNick] = useState(currentUser.name);
  const [allowPM, setAllowPM] = useState(true);
  const [blockedUsers, setBlockedUsers] = useState<string[]>([]); // Store blocked User IDs

  const activeRoom = rooms.find(r => r.id === activeRoomId) || rooms[0];

  // Tab Switching Logic (Clears Alert)
  const handleSwitchTab = (roomId: string) => {
      setActiveRoomId(roomId);
      setRooms(prev => prev.map(r => r.id === roomId ? { ...r, hasAlert: false } : r));
  };

  // Close Tab logic
  const handleCloseTab = (e: React.MouseEvent, roomId: string) => {
      e.stopPropagation();
      const roomIndex = rooms.findIndex(r => r.id === roomId);
      if (rooms.length === 1) return; // Cannot close last tab

      const newRooms = rooms.filter(r => r.id !== roomId);
      setRooms(newRooms);
      
      if (activeRoomId === roomId) {
          // Switch to previous tab or first tab
          const newActive = newRooms[roomIndex - 1] || newRooms[0];
          setActiveRoomId(newActive.id);
      }
  };

  const handleSendMessage = useCallback(async (text: string) => {
    const newMessage: Message = {
      id: `msg-${Date.now()}`,
      senderId: currentUser.id,
      text,
      timestamp: Date.now()
    };

    setRooms(prev => prev.map(room => {
      if (room.id === activeRoomId) {
        return {
          ...room,
          messages: [...room.messages, newMessage],
          lastMessageAt: Date.now()
        };
      }
      return room;
    }));

    // If channel, bots might respond globally. 
    // If Private, ONLY the target bot responds.
    const currentRoom = rooms.find(r => r.id === activeRoomId);
    if (!currentRoom) return;

    if (currentRoom.type === 'channel') {
        const aiParticipants = currentRoom.participants.filter(p => p.isAi);
        if (aiParticipants.length > 0) {
            // Random chance for bot to reply in channel
            const randomBot = aiParticipants[Math.floor(Math.random() * aiParticipants.length)];
            setTimeout(() => triggerBotResponse(randomBot.id, currentRoom.id, text), 500);
        }
    } else if (currentRoom.type === 'private' && currentRoom.targetUserId) {
        // Direct reply in PM
        const targetBotId = currentRoom.targetUserId;
        setTimeout(() => triggerBotResponse(targetBotId, currentRoom.id, text), 500);
    }

  }, [activeRoomId, rooms, currentUser.id]);

  const triggerBotResponse = async (botId: string, roomId: string, userMessageContext?: string) => {
    // Check if bot is blocked
    if (blockedUsers.includes(botId)) return;

    const room = rooms.find(r => r.id === roomId);
    if (!room) return;

    // Find the bot in the room OR in global bot list (for PMs)
    let bot = room.participants.find(p => p.id === botId);
    if (!bot) {
         bot = PREMADE_BOTS.find(p => p.id === botId);
    }
    if (!bot) return;

    setLoadingState({ status: 'thinking', participantId: botId });
    
    // Simulate thinking delay
    await new Promise(r => setTimeout(r, 1000 + Math.random() * 2000));

    const responseText = await generateBotResponse(
        bot,
        room.participants,
        room.messages, 
        room.topic
    );

    const botMessage: Message = {
        id: `msg-${Date.now()}`,
        senderId: bot.id,
        text: responseText,
        timestamp: Date.now()
    };

    setRooms(prev => prev.map(r => {
        if (r.id === roomId) {
            // Check if user is looking at this room. If not, Alert!
            const isLooking = (roomId === activeRoomId);
            return {
                ...r,
                messages: [...r.messages, botMessage],
                lastMessageAt: Date.now(),
                hasAlert: !isLooking // Blink if not active
            };
        }
        return r;
    }));

    setLoadingState({ status: 'idle' });
  };

  // --- FEATURES ---

  // 1. Double Click User -> Open Private Chat
  const handleUserDoubleClick = (participant: Participant) => {
      if (participant.id === currentUser.id) return; // Can't chat with self
      if (!allowPM) {
          alert("Özel mesajlarınız kapalı. Ayarlardan açabilirsiniz.");
          return;
      }
      if (blockedUsers.includes(participant.id)) {
          alert("Bu kullanıcıyı engellediniz.");
          return;
      }

      // Check if room already exists
      const existingRoom = rooms.find(r => r.type === 'private' && r.targetUserId === participant.id);
      if (existingRoom) {
          setActiveRoomId(existingRoom.id);
          return;
      }

      // Create new Private Room
      const newPrivateRoom: ChatRoom = {
          id: `pm-${participant.id}`,
          name: participant.name, // Display Name
          topic: `${participant.name} ile özel sohbet`,
          type: 'private',
          targetUserId: participant.id,
          participants: [currentUser, participant],
          messages: [],
          lastMessageAt: Date.now(),
          hasAlert: false
      };

      setRooms(prev => [...prev, newPrivateRoom]);
      setActiveRoomId(newPrivateRoom.id);
  };

  // 2. Change Nickname & Settings
  const handleSaveSettings = () => {
      if (tempNick.trim()) {
          setCurrentUser(prev => ({ ...prev, name: tempNick }));
          // Update user in all rooms
          setRooms(prev => prev.map(room => ({
              ...room,
              participants: room.participants.map(p => p.id === currentUser.id ? { ...p, name: tempNick } : p)
          })));
      }
      setShowSettingsModal(false);
  };

  // 3. Block / Unblock Logic
  const toggleBlockUser = (userId: string) => {
      setBlockedUsers(prev => {
          if (prev.includes(userId)) return prev.filter(id => id !== userId);
          return [...prev, userId];
      });
  };

  // 4. Logout
  const handleLogout = () => {
      if (confirm("Çıkış yapmak istediğinize emin misiniz?")) {
          setCurrentView('LANDING');
      }
  };

  // Add Bot to Channel
  const handleAddBot = (bot: Participant) => {
    setRooms(prev => prev.map(r => {
        if (r.id === activeRoomId && r.type === 'channel') {
            // Don't add if exists
            if (r.participants.find(p => p.id === bot.id)) return r;
            return { ...r, participants: [...r.participants, bot] };
        }
        return r;
    }));
  };

  const handleRemoveParticipant = (id: string) => {
      setRooms(prev => prev.map(r => {
          if (r.id === activeRoomId) {
              return { ...r, participants: r.participants.filter(p => p.id !== id) };
          }
          return r;
      }));
  };

  const handleCreateRoom = (e: React.FormEvent) => {
      e.preventDefault();
      if (!newRoomName.trim()) return;

      const newRoom: ChatRoom = {
          id: `room-${Date.now()}`,
          name: newRoomName.startsWith('#') ? newRoomName : `#${newRoomName}`,
          topic: 'Genel Sohbet',
          type: 'channel',
          participants: [currentUser, PREMADE_BOTS[0]],
          messages: [{
              id: 'msg-init',
              senderId: PREMADE_BOTS[0].id,
              text: 'Kanal oluşturuldu. Hoş geldiniz.',
              timestamp: Date.now()
          }],
          lastMessageAt: Date.now(),
          hasAlert: false
      };

      setRooms([...rooms, newRoom]);
      setActiveRoomId(newRoom.id);
      setShowCreateModal(false);
      setNewRoomName('');
  };

  // --- VIEW RENDERING ---

  if (currentView === 'LANDING') {
    return <LandingPage 
      onEnter={() => setCurrentView('CHAT')} 
      onRegisterClick={() => setCurrentView('REGISTER')}
      onAdminClick={() => setCurrentView('ADMIN')}
    />;
  }

  if (currentView === 'REGISTER') {
    return <RegistrationForm 
      onClose={() => setCurrentView('LANDING')}
      onSuccess={() => {
        alert("Başvurunuz başarıyla alındı! Yönetici onayından sonra giriş yapabilirsiniz.");
        setCurrentView('LANDING');
      }}
    />;
  }

  if (currentView === 'ADMIN') {
    return <AdminDashboard onLogout={() => setCurrentView('LANDING')} />;
  }

  // --- CHAT INTERFACE ---
  return (
    <div className="fixed inset-0 flex flex-col overflow-hidden bg-[#d4dce8] font-sans">
      
      {/* 1. Header Bar (mIRC Style) */}
      <header className="h-9 bg-[#000080] flex items-center justify-between px-2 text-white shrink-0 shadow-sm select-none border-b-2 border-white">
         <div className="flex items-center gap-2 overflow-hidden">
            <div className="w-4 h-4 shrink-0 rounded-sm bg-gradient-to-br from-red-500 to-red-700 border border-white shadow-sm flex items-center justify-center">
               <div className="w-2 h-2 bg-white rounded-full"></div>
            </div>
            <span className="font-bold text-xs tracking-wide text-white drop-shadow-md truncate">
               Workigom Chat - [{currentUser.name}]
            </span>
         </div>
         <div className="flex gap-2 text-[10px] font-bold shrink-0">
             <button 
                onClick={() => setShowSettingsModal(true)}
                className="flex items-center gap-1 hover:text-yellow-300 transition-colors"
             >
                 <Settings size={12} /> <span className="hidden sm:inline">AYARLAR</span>
             </button>
             <div className="w-px bg-gray-400 mx-1"></div>
             <button 
                onClick={handleLogout}
                className="flex items-center gap-1 hover:text-red-400 transition-colors"
             >
                 <Power size={12} /> <span className="hidden sm:inline">ÇIKIŞ</span>
             </button>
         </div>
      </header>

      {/* 2. Toolbar (Minimal) */}
      <div className="flex gap-1 p-1 bg-[#d4dce8] border-b border-gray-400">
         <div className="h-6 w-6 border border-gray-400 bg-white flex items-center justify-center cursor-pointer active:translate-y-px shadow-sm" title="Bağlı"><Shield size={14} color="green"/></div>
         <div className="h-6 w-0.5 border-l border-gray-400 border-r border-white mx-1"></div>
         <span className="text-[10px] text-gray-600 flex items-center truncate">
             Durum: <span className="text-green-700 font-bold ml-1">Bağlı ({currentUser.name})</span>
         </span>
      </div>

      {/* 3. Tabs & Workspace */}
      <div className="flex-1 flex flex-col min-h-0 p-1">
          
          {/* Tabs */}
          <div className="flex items-end px-1 gap-0.5 overflow-x-auto select-none shrink-0 bg-[#000080] pt-1 border-t border-l border-r border-black mx-0.5">
             {rooms.map(room => (
                <button
                   key={room.id}
                   onClick={() => handleSwitchTab(room.id)}
                   className={`
                      px-3 py-1 text-xs font-bold rounded-t-[3px] min-w-[90px] max-w-[150px] flex items-center justify-between gap-2 transition-colors duration-100
                      ${activeRoomId === room.id 
                         ? 'bg-[#d4dce8] text-black border-t-2 border-l-2 border-white border-r-2 border-r-gray-600 mb-0 pb-1.5 z-10' 
                         : (room.hasAlert ? 'bg-red-600 text-white animate-pulse mb-0.5' : 'bg-[#b0b8c4] text-gray-700 border border-gray-500 hover:bg-[#c0c8d4] mb-0.5')}
                   `}
                >
                   <span className="truncate">{room.name}</span>
                   {/* Close Button */}
                   <span 
                     onClick={(e) => handleCloseTab(e, room.id)}
                     className={`rounded text-[10px] font-bold px-1 hover:bg-black/10 ${activeRoomId === room.id ? 'hover:text-red-600' : 'text-gray-500 hover:text-white'}`}
                   >
                     x
                   </span>
                </button>
             ))}
             <button 
                onClick={() => setShowCreateModal(true)}
                className="px-2 py-0.5 text-white hover:text-yellow-300 font-bold text-xs mb-1"
                title="Yeni Kanal"
             >
                +
             </button>
          </div>

          {/* Main Area Container */}
          <div className="flex-1 flex border-2 border-white border-r-gray-600 border-b-gray-600 bg-white shadow-inner relative z-0">
            {/* Chat Area (Left/Center) */}
            <div className="flex-1 flex flex-col h-full min-w-0">
                <ChatArea 
                    room={activeRoom}
                    currentUser={currentUser}
                    onSendMessage={handleSendMessage}
                    loadingState={loadingState}
                    onTriggerBot={(botId) => triggerBotResponse(botId, activeRoomId)}
                    isBlocked={activeRoom.type === 'private' && blockedUsers.includes(activeRoom.targetUserId || '')}
                    onToggleBlock={() => activeRoom.targetUserId && toggleBlockUser(activeRoom.targetUserId)}
                />
            </div>

            {/* User List (Right - Persistent) - Only show for Channels */}
            {activeRoom.type === 'channel' && (
                <RightPanel 
                    room={activeRoom}
                    onAddBot={handleAddBot}
                    onRemoveParticipant={handleRemoveParticipant}
                    onUserDoubleClick={handleUserDoubleClick}
                />
            )}
          </div>
      </div>

      {/* Settings Modal */}
      {showSettingsModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-[1px]">
              <div className="bg-[#d4dce8] border-2 border-white shadow-[4px_4px_10px_rgba(0,0,0,0.5)] w-full max-w-xs flex flex-col">
                  <div className="bg-[#000080] text-white px-2 py-0.5 flex justify-between items-center select-none">
                      <span className="text-xs font-bold">Ayarlar</span>
                      <button onClick={() => setShowSettingsModal(false)} className="hover:bg-red-600 px-1"><X size={12}/></button>
                  </div>
                  <div className="p-4 space-y-4 border-2 border-[#d4dce8] border-t-white border-l-white border-b-gray-600 border-r-gray-600 m-1">
                      <div>
                          <label className="block text-xs text-black mb-1 font-bold">Rumuz (Nick):</label>
                          <input 
                              type="text" 
                              value={tempNick}
                              onChange={e => setTempNick(e.target.value)}
                              className="w-full border-2 border-gray-600 border-r-white border-b-white p-1 text-sm outline-none font-mono"
                          />
                      </div>
                      <div className="flex items-center gap-2">
                          <input 
                             type="checkbox" 
                             id="allowPM"
                             checked={allowPM}
                             onChange={e => setAllowPM(e.target.checked)}
                             className="cursor-pointer"
                          />
                          <label htmlFor="allowPM" className="text-xs cursor-pointer select-none">Özel Mesajlara İzin Ver</label>
                      </div>
                      <div className="flex justify-end pt-2">
                          <button onClick={handleSaveSettings} className="px-4 py-1 bg-[#d4dce8] text-black text-xs font-bold border-2 border-white border-b-black border-r-black active:border-t-black active:border-l-black flex items-center gap-1">
                              <Save size={12}/> KAYDET
                          </button>
                      </div>
                  </div>
              </div>
          </div>
      )}

      {/* Create Room Modal */}
      {showCreateModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-[1px]">
              <div className="bg-[#d4dce8] border-2 border-white shadow-[4px_4px_10px_rgba(0,0,0,0.5)] w-full max-w-sm flex flex-col">
                  <div className="bg-[#000080] text-white px-2 py-0.5 flex justify-between items-center select-none">
                      <span className="text-xs font-bold">Kanal Oluştur</span>
                      <button onClick={() => setShowCreateModal(false)} className="hover:bg-red-600 px-1"><X size={12}/></button>
                  </div>
                  <form onSubmit={handleCreateRoom} className="p-4 space-y-4 border-2 border-[#d4dce8] border-t-white border-l-white border-b-gray-600 border-r-gray-600 m-1">
                      <div>
                          <label className="block text-xs text-black mb-1">Kanal Adı:</label>
                          <input 
                              type="text" 
                              autoFocus
                              value={newRoomName}
                              onChange={e => setNewRoomName(e.target.value)}
                              className="w-full border-2 border-gray-600 border-r-white border-b-white p-1 text-sm outline-none font-mono shadow-[inset_1px_1px_2px_rgba(0,0,0,0.2)]"
                              placeholder="#yeni_oda"
                          />
                      </div>
                      <div className="flex justify-end gap-2 pt-2">
                          <button type="button" onClick={() => setShowCreateModal(false)} className="px-4 py-1 bg-[#d4dce8] text-black text-xs border-2 border-white border-b-black border-r-black active:border-t-black active:border-l-black">İptal</button>
                          <button type="submit" className="px-4 py-1 bg-[#d4dce8] text-black text-xs font-bold border-2 border-white border-b-black border-r-black active:border-t-black active:border-l-black">Oluştur</button>
                      </div>
                  </form>
              </div>
          </div>
      )}
    </div>
  );
};

export default App;