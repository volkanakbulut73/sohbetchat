
import { useState, useCallback, useEffect } from 'react';
import { Message, MessageType } from '../types';
import { storageService, supabase } from '../services/storageService';
import { groqService } from '../services/groqService';

export const useChatCore = (initialUserName: string) => {
  const [userName, setUserName] = useState(() => localStorage.getItem('mirc_nick') || initialUserName);
  const [openTabs, setOpenTabs] = useState<string[]>(['#sohbet', '#yardim', '#radyo']);
  const [unreadTabs, setUnreadTabs] = useState<string[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [activeTab, setActiveTab] = useState<string>('#sohbet');
  const [blockedUsers, setBlockedUsers] = useState<string[]>([]);
  const [allowPrivateMessages, setAllowPrivateMessages] = useState(true);
  const [onlineUsers, setOnlineUsers] = useState<string[]>(['Admin', 'Lara']);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const fetchUsers = useCallback(async () => {
    if (!storageService.isConfigured() || !navigator.onLine) return;
    try {
      const regs = await storageService.getAllRegistrations();
      if (regs && Array.isArray(regs)) {
        const approvedNicks = regs
          .filter(r => r.status === 'approved' && !['lara', 'admin'].includes(r.nickname.toLowerCase()))
          .map(r => r.nickname);
        
        const fullList = Array.from(new Set(['Admin', 'Lara', ...approvedNicks]));
        setOnlineUsers(fullList);
      }
    } catch (e) {
      setOnlineUsers(['Admin', 'Lara']);
    }
  }, []);

  useEffect(() => {
    fetchUsers();
    const interval = setInterval(fetchUsers, 20000);
    return () => clearInterval(interval);
  }, [fetchUsers]);

  // Hoşgeldin Mesajı (Groq - Lara Bot)
  useEffect(() => {
    if (activeTab === '#sohbet' && userName && isOnline && messages.length > 0) {
      const hasGreeting = messages.some(m => m.sender === 'Lara' && m.text.toLowerCase().includes('hoş geldin'));
      if (!hasGreeting) {
        setTimeout(async () => {
          const greet = await groqService.getChatResponse("Kanala yeni gelen birine mIRC jargonunda samimi bir hoşgeldin mesajı yaz.", userName);
          if (greet) {
            await storageService.saveMessage({
              sender: 'Lara',
              text: greet,
              type: MessageType.USER,
              channel: '#sohbet'
            });
          }
        }, 3000);
      }
    }
  }, [activeTab, userName, messages.length, isOnline]);

  const getPrivateChannelId = (user1: string, user2: string) => {
    const sorted = [user1, user2].sort();
    return `private:${sorted[0]}:${sorted[1]}`;
  };

  const sendMessage = async (text: string) => {
    if (!text.trim() || !userName) return;

    const newMessage: Omit<Message, 'id' | 'timestamp'> = {
      sender: userName,
      text,
      type: MessageType.USER,
      channel: activeTab
    };

    try {
      await storageService.saveMessage(newMessage);

      // Bot Komutu Kontrolü (@Lara)
      if (text.toLowerCase().includes('@lara')) {
        const botResponse = await groqService.getChatResponse(text.replace('@lara', '').trim(), userName);
        await storageService.saveMessage({
          sender: 'Lara',
          text: botResponse,
          type: MessageType.USER,
          channel: activeTab
        });
      }
    } catch (e) {
      console.error("Message send error:", e);
    }
  };

  const initiatePrivateChat = (targetNick: string) => {
    if (targetNick === userName || targetNick === 'Admin' || targetNick === 'Lara') return;
    const channelId = getPrivateChannelId(userName, targetNick);
    if (!openTabs.includes(targetNick)) {
      setOpenTabs(prev => [...prev, targetNick]);
    }
    setActiveTab(targetNick);
  };

  const closeTab = (tab: string) => {
    if (tab.startsWith('#')) return;
    setOpenTabs(prev => prev.filter(t => t !== tab));
    if (activeTab === tab) setActiveTab('#sohbet');
  };

  const toggleBlock = (nick: string) => {
    setBlockedUsers(prev => 
      prev.includes(nick) ? prev.filter(u => u !== nick) : [...prev, nick]
    );
  };

  // Realtime Mesaj Dinleyici
  useEffect(() => {
    if (!storageService.isConfigured()) return;

    const channel = supabase
      .channel('public:messages')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, (payload) => {
        const newMsg = payload.new as any;
        const msgChannel = newMsg.channel;

        // Mesajın bu kullanıcıyla ilgili olup olmadığını kontrol et
        const isPublic = msgChannel.startsWith('#');
        const isPrivateForMe = !isPublic && msgChannel.includes(userName);

        if (isPublic || isPrivateForMe) {
          const formattedMsg: Message = {
            id: newMsg.id.toString(),
            sender: newMsg.sender,
            text: newMsg.text,
            timestamp: new Date(newMsg.created_at).getTime(),
            type: newMsg.type as MessageType,
            channel: msgChannel
          };

          // Eğer mesaj aktif olmayan bir tab'a geldiyse unread işaretle
          const targetTab = isPublic ? msgChannel : (newMsg.sender === userName ? activeTab : newMsg.sender);
          
          if (targetTab !== activeTab) {
            setUnreadTabs(prev => Array.from(new Set([...prev, targetTab])));
            if (!isPublic && !openTabs.includes(targetTab)) {
              setOpenTabs(prev => [...prev, targetTab]);
            }
          }

          // Sadece aktif kanalın mesajlarını state'de tut
          if (targetTab === activeTab) {
            setMessages(prev => [...prev, formattedMsg]);
          }
        }
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [activeTab, userName, openTabs]);

  // Kanal değiştiğinde mesajları yükle
  useEffect(() => {
    const loadMessages = async () => {
      setMessages([]);
      const channelName = activeTab.startsWith('#') ? activeTab : getPrivateChannelId(userName, activeTab);
      const history = await storageService.getMessagesByChannel(channelName);
      setMessages(history);
      setUnreadTabs(prev => prev.filter(t => t !== activeTab));
    };
    loadMessages();
  }, [activeTab, userName]);

  return {
    userName, setUserName,
    activeTab, setActiveTab,
    openTabs, unreadTabs,
    messages, sendMessage,
    initiatePrivateChat,
    onlineUsers,
    blockedUsers, toggleBlock,
    closeTab, isOnline,
    allowPrivateMessages, setAllowPrivateMessages
  };
};
