
export enum MessageType {
  USER = 'USER',
  SYSTEM = 'SYSTEM',
  ERROR = 'ERROR'
}

export interface Participant {
  id: string;
  name: string;
  persona: string; // The system instruction/personality
  avatar: string;
  isAi: boolean;
  color: string; // Tailwind color class for avatar bg
}

export interface Message {
  id: string;
  senderId?: string; // Used by main App
  sender?: string;   // Used by mIRC components
  text: string;
  timestamp: number;
  type?: MessageType; // Used by mIRC components
  channel?: string;   // Used by mIRC components
}

export interface ChatRoom {
  id: string;
  name: string;
  topic: string;
  participants: Participant[];
  messages: Message[];
  lastMessageAt: number;
  type: 'channel' | 'private'; // New: Distinguish between channels and PMs
  targetUserId?: string; // New: For private chats, who are we talking to?
  hasAlert?: boolean; // New: For blinking tabs
}

export interface LoadingState {
  status: 'idle' | 'thinking' | 'error';
  participantId?: string; // Who is thinking?
}

export enum ViewState {
  CHAT = 'CHAT',
  SETTINGS = 'SETTINGS',
  CREATE_ROOM = 'CREATE_ROOM'
}

export interface UserRegistration {
  id?: string;
  nickname: string;
  fullName?: string;
  full_name?: string; // Supabase raw
  email: string;
  password?: string;
  criminal_record_file?: string | null;
  insurance_file?: string | null;
  status: 'pending' | 'approved' | 'rejected';
  created_at?: string;
}

export interface Channel {
  id?: number | string;
  name: string;
  unreadCount?: number;
  users?: string[];
  islocked?: boolean;
  ops?: string[];
  bannedusers?: string[];
}
